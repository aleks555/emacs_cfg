@decorator1()
@decorator2()
@decorator3()
class Name {

}
