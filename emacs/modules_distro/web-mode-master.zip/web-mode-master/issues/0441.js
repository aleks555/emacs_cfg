var cs = {completed: this.props.todo.completed,
          editing: this.props.editing};
return {
  nowShowing: Const.ALL_TODOS,
  editing: null
};
